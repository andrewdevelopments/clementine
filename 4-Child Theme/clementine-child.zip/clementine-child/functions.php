<?php
#-------------------------------------------------#
# Clementine Child theme functions                #
#-------------------------------------------------#

// No direct access
if ( !defined('ABSPATH') ) exit;
?>